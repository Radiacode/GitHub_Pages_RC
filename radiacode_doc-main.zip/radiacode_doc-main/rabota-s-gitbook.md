---
description: Большая часть изменений вносится путем начала строки с символа /
---

# Работа с Gitbook

Информация о блоках

[https://docs.gitbook.com/content-editor/blocks](https://docs.gitbook.com/content-editor/blocks)
