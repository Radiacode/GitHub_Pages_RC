# Table of contents

* [Device design](README.md)
* [Radiacode-10X series](radiacode-10x-series/README.md)
  * [Before use](<Radiacode-10X series/Before use.md>)
  * [Technical specifications](<Radiacode-10X series/Technical specifications.md>)
  * [Working with a PC](<Radiacode-10X series/Working with a PC.md>)
  * [Working with a smartphone](<Radiacode-10X series/Working with a smartphone.md>)
* [Работа с Gitbook](rabota-s-gitbook.md)
